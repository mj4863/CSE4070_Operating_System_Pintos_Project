#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include <string.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "userprog/process.h"

static void syscall_handler (struct intr_frame *);

void check_user_vaddr(const void *vaddr){
	if(!is_user_vaddr(vaddr)) exit(-1);
}

void halt(void){
  shutdown_power_off();
}

void exit(int status) {
  struct thread *t = thread_current();
  printf("%s: exit(%d)\n", thread_name(), status);
  t->exit_status = status;
  thread_exit();
}

pid_t exec(const char *cmd_line){
  return process_execute(cmd_line);
}

int wait(pid_t pid){
  return process_wait(pid);
}

int read(int fd, void *buffer, unsigned size) {
  if (fd == 0) { 
    for (unsigned i = 0; i < size; i++) {
        ((char *)buffer)[i] = input_getc();
    }
    return size;
  }
  return -1;
}

int write(int fd, const void *buffer, unsigned size){
  if (fd == 1) {
    putbuf(buffer, size);
    return size;
  }
  return -1;
}

int fibonacci(int n) {
  int a = 0, b = 1, fib = 0;

  if (!n) return a; 

  for (int i = 2; i <= n; i++) {
      fib = a + b; 
      a = b; 
      b = fib;
  }
  return b;
}

int max_of_four_int(int a, int b, int c, int d) {
  int x = a > b ? a : b;
  int y = c > d ? c : d;
  return x > y ? x : y;
}

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  switch (*(uint32_t *)f->esp) {
    case SYS_HALT:
      halt();
      break;
    case SYS_EXIT:
      check_user_vaddr(f->esp + 4);
      exit((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_EXEC:
      check_user_vaddr(f->esp + 4);
      f->eax = exec((char *)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_WAIT:
      check_user_vaddr(f->esp + 4);
      f->eax = wait((pid_t)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_READ:
      check_user_vaddr(f->esp + 4);
      check_user_vaddr(f->esp + 8);
      check_user_vaddr(f->esp + 12);
      f->eax = read((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8),
		     (unsigned)*(uint32_t *)(f->esp + 12));
      break;
    case SYS_WRITE:
      check_user_vaddr(f->esp + 4);
      check_user_vaddr(f->esp + 8);
      check_user_vaddr(f->esp + 12);
      f->eax = write((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8),
		     (unsigned)*(uint32_t *)(f->esp + 12));
      break;
    case SYS_FIBONACCI:
      check_user_vaddr(f->esp + 4);
      f->eax = fibonacci((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_MAX_OF_FOUR_INT:
      check_user_vaddr(f->esp + 4);
      check_user_vaddr(f->esp + 8);
      check_user_vaddr(f->esp + 12);
      check_user_vaddr(f->esp + 16);
      f->eax = max_of_four_int((int)*(uint32_t *)(f->esp + 4), (int)*(uint32_t *)(f->esp + 8), 
        (int)*(uint32_t *)(f->esp + 12), (int)*(uint32_t *)(f->esp + 16));
      break;
  }
}
