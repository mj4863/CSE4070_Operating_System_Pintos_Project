#include <stdio.h>
#include <syscall-nr.h>
#include <string.h>
#include "userprog/process.h"
#include "userprog/syscall.h"

#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/synch.h"
#include "threads/malloc.h"

#include "filesys/filesys.h"
#include "devices/input.h"
#include "devices/shutdown.h"
#include "vm/mmap.h"

static void syscall_handler(struct intr_frame *);
struct lock file_lock;

void check_user_vaddr(const void *vaddr){
	if (!is_user_vaddr(vaddr) || pagedir_get_page(thread_current()->pagedir, vaddr) == NULL) {
      exit(-1);
  }
}

void halt(void){
  shutdown_power_off();
}

void exit(int status) {
  struct thread *t = thread_current();
  printf("%s: exit(%d)\n", thread_name(), status);
  t->exit_status = status;

  for(int i = 3; i < 128; i++) {
    if(t->fd[i]) close(i);
  }

  for (unsigned int i = 1; i < t->map_list_size; i++)
    munmap(i);

  file_close(t->file);
  pt_destroy(&(t->pt));

  thread_exit();
}

pid_t exec(const char *cmd_line){
  check_user_vaddr(cmd_line);
  return process_execute(cmd_line);
}

int wait(pid_t pid){
  return process_wait(pid);
}

int read(int fd, void *buffer, unsigned size)
{
  if (!buffer || !is_user_vaddr(buffer))
    exit(-1);

  lock_acquire(&file_lock);

  struct file *f = (fd >= 3 && fd < 128) ? thread_current()->fd[fd] : NULL;
  off_t bytes = 0;

  if (fd == 0)
  {
    char *buf_ptr = (char *)buffer;
    for (unsigned i = 0; i < size; ++i)
    {
      char c = input_getc();
      if (c == '\0')
        break;
      buf_ptr[i] = c;
      bytes++;
    }
    buf_ptr[bytes] = '\0';
  }
  else if (!f)
  {
    lock_release(&file_lock);
    exit(-1);
  }
  else
    bytes = file_read(f, buffer, size);

  lock_release(&file_lock);
  return bytes;
}

int write(int fd, const void *buffer, unsigned size){
  check_user_vaddr(buffer);
  int bytes_written = -1;

  lock_acquire(&file_lock);
  if (fd == 1) {
    putbuf(buffer, size);
    bytes_written = size;
  }
  else if (fd > 2 && fd < 128) {
    struct file *file = thread_current()->fd[fd];
    if (!file) {
      lock_release(&file_lock);
      exit(-1);
    }
    bytes_written = file_write(file, buffer, size);
  }

  lock_release(&file_lock);
  return bytes_written;
}

int fibonacci(int n) {
  int a = 0, b = 1, fib = 0;

  if (!n) return a; 

  for (int i = 2; i <= n; i++) {
      fib = a + b; 
      a = b; 
      b = fib;
  }
  return b;
}

int max_of_four_int(int a, int b, int c, int d) {
  int x = a > b ? a : b;
  int y = c > d ? c : d;
  return x > y ? x : y;
}

bool create(const char *file, unsigned initial_size) {
  if(!file) exit(-1);
  
  lock_acquire(&file_lock);
  bool success = filesys_create(file, initial_size);
  lock_release(&file_lock);

  return success;
}

bool remove (const char *file) {
  if(!file) exit(-1);
  return filesys_remove(file);
}

int open (const char *file) {
  if(!file) return -1;

  lock_acquire(&file_lock);
  struct file *f = filesys_open(file);
  int idx = -1;

  if (f != NULL) {
    for (int i = 3; i < 128; i++) {
      if (thread_current()->fd[i] == NULL) {
        thread_current()->fd[i] = f;
        idx = i;
        break;
      }
    }
    if (idx == -1) {
      file_close(f);
    } 
    else if (!strcmp(thread_current()->name, file)) {
      file_deny_write(f);
      thread_current()->deny_write_file = true;
    }
  }

  lock_release(&file_lock);
	return idx;
}

int filesize(int fd)
{
  if (fd < 3 || fd >= 128)
    exit(-1);

  lock_acquire(&file_lock);

  struct file *f = thread_current()->fd[fd];
  if (!f)
  {
    lock_release(&file_lock);
    exit(-1);
  }
  int size = file_length(f);

  lock_release(&file_lock);

  return size;
}

void seek(int fd, unsigned position) {
  struct file *f = thread_current()->fd[fd];
  file_seek(f, position);
}

unsigned tell(int fd) {
  struct file *f = thread_current()->fd[fd];
  return file_tell(f);
}

void close(int fd) {
  struct thread *cur = thread_current();

  if (fd < 3 || fd >= 128 || cur->fd[fd] == NULL) exit(-1);
  
  if (cur->deny_write_file) {
    file_allow_write(cur->fd[fd]);
    cur->deny_write_file = false;
  }

  file_close(cur->fd[fd]);
  cur->fd[fd] = NULL;
}

unsigned int mmap(int fd, void *addr)
{
  return mm_map(fd, addr);
}

void munmap(unsigned int mapid)
{
  mm_free(mapid);
  return;
}

void syscall_init(void)
{
  lock_init(&file_lock);
  intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  switch (*(uint32_t *)f->esp) {
    case SYS_HALT:
      halt();
      break;
    case SYS_EXIT:
      check_user_vaddr(f->esp + 4);
      exit((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_EXEC:
      check_user_vaddr(f->esp + 4);
      f->eax = exec((char *)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_WAIT:
      check_user_vaddr(f->esp + 4);
      f->eax = wait((pid_t)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_READ:
      check_user_vaddr(f->esp + 4);
      check_user_vaddr(f->esp + 8);
      check_user_vaddr(f->esp + 12);
      f->eax = read((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8),
		     (unsigned)*(uint32_t *)(f->esp + 12));
      break;
    case SYS_WRITE:
      check_user_vaddr(f->esp + 4);
      check_user_vaddr(f->esp + 8);
      check_user_vaddr(f->esp + 12);
      f->eax = write((int)*(uint32_t *)(f->esp + 4), (void *)*(uint32_t *)(f->esp + 8),
		     (unsigned)*(uint32_t *)(f->esp + 12));
      break;
    case SYS_FIBONACCI:
      check_user_vaddr(f->esp + 4);
      f->eax = fibonacci((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_MAX_OF_FOUR_INT:
      check_user_vaddr(f->esp + 4);
      check_user_vaddr(f->esp + 8);
      check_user_vaddr(f->esp + 12);
      check_user_vaddr(f->esp + 16);
      f->eax = max_of_four_int((int)*(uint32_t *)(f->esp + 4), (int)*(uint32_t *)(f->esp + 8), 
        (int)*(uint32_t *)(f->esp + 12), (int)*(uint32_t *)(f->esp + 16));
      break;
    case SYS_CREATE:
      check_user_vaddr(f->esp + 4);
      check_user_vaddr(f->esp + 8);
      f->eax = create((const char *)*(uint32_t *)(f->esp + 4), (unsigned)*(uint32_t *)(f->esp + 8));
      break;
    case SYS_REMOVE:
      check_user_vaddr(f->esp + 4);
      f->eax = remove((const char *)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_OPEN:
      check_user_vaddr(f->esp + 4);
      f->eax = open((const char *)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_FILESIZE:
      check_user_vaddr(f->esp + 4);
      f->eax = filesize((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_SEEK:
      check_user_vaddr(f->esp + 4);
      check_user_vaddr(f->esp + 8);
      seek((int)*(uint32_t *)(f->esp + 4), (unsigned)*(uint32_t *)(f->esp + 8));
      break;
    case SYS_TELL:
      check_user_vaddr(f->esp + 4);
      f->eax = tell((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_CLOSE:
      check_user_vaddr(f->esp + 4);
      close((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_MMAP:
      check_user_vaddr(f->esp + 4); 
      check_user_vaddr(f->esp + 8);
      f->eax = mmap(*(int *)(uint32_t *)(f->esp + 4), *(void **)(uint32_t *)(f->esp + 8));
      break;
    case SYS_MUNMAP:
      check_user_vaddr(f->esp + 4);
      munmap(*(unsigned int *)(uint32_t *)(f->esp + 4));
      break;
  }
}