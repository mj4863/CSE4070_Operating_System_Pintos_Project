#ifndef VM_SWAP_H
#define VM_SWAP_H

#include <stddef.h>
#include <bitmap.h>

void swap_init(void);
void swap_in(size_t index, void *kaddr);
size_t swap_out(void *kaddr);
bool swap_data(size_t swap_index, void *kaddr, bool is_read);
size_t find_swap_index(void);
void swap_free(size_t index);

#endif