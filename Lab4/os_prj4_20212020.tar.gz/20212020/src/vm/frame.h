#ifndef VM_FRAME_H
#define VM_FRAME_H

#include <list.h>
#include "vm/page.h"
#include "threads/synch.h"
#include "threads/thread.h"

struct frame {
  void *kaddr;
  struct thread *owner;
  struct pt_entry *pte;
  struct list_elem elem;
};

struct list frame_list;
struct list_elem *victim;

void frame_init(void);
struct frame *frame_alloc(enum palloc_flags flags);
void frame_free(void *kaddr);
bool frame_load(void *kaddr, struct pt_entry *pte);
void frame_remove(struct frame *frame);
struct list_elem *frame_victim(void);
void frame_evict(void);

#endif