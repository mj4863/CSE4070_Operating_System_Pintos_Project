#include "vm/frame.h"
#include "vm/swap.h"
#include "lib/string.h"
#include "threads/malloc.h"

struct lock frame_lock;

void frame_init(void) {
  lock_init(&frame_lock);
  list_init(&frame_list);
  victim = NULL;
}

struct frame *frame_alloc(enum palloc_flags flags) {
  struct frame *frame = (struct frame *)malloc(sizeof(struct frame));
  
  if (frame == NULL)
    return NULL;

  memset(frame, 0, sizeof(struct frame));
  frame->owner = thread_current();

  lock_acquire(&frame_lock);
  frame->kaddr = palloc_get_page(flags);

  while (frame->kaddr == NULL) {
      frame_evict();
      frame->kaddr = palloc_get_page(flags);
  }

  list_push_back(&frame_list, &frame->elem);
  lock_release(&frame_lock);

  return frame;
}

void frame_free(void *kaddr) {
  if (kaddr == NULL) {
      return;
  }

  lock_acquire(&frame_lock);

  struct frame *frame = NULL;

  struct list_elem *e = list_begin(&frame_list);
  while (e != list_end(&frame_list)) {
    struct frame *f = list_entry(e, struct frame, elem);
    if (f->kaddr == kaddr) {
      frame = f;
      break;
    }
    e = list_next(e);
  }

  if (frame != NULL) {
      frame_remove(frame);
      pagedir_clear_page(frame->owner->pagedir, frame->pte->vaddr);
      palloc_free_page(frame->kaddr);
      free(frame);
  }

  lock_release(&frame_lock);
}

bool frame_load(void *kaddr, struct pt_entry *pte) {
  if (pte == NULL || kaddr == NULL) {
      return false;
  }

  lock_acquire(&frame_lock);

  size_t bytes_read = file_read_at(pte->file, kaddr, pte->read_bytes, pte->offset);
  if (bytes_read != pte->read_bytes) {
      lock_release(&frame_lock);
      return false;
  }

  memset((uint8_t *)kaddr + bytes_read, 0, pte->zero_bytes);

  lock_release(&frame_lock);
  return true;
}

void frame_remove(struct frame *frame) {
  struct list_elem *entry = &frame->elem;
  struct list_elem *ret = list_remove(entry);

  if (victim == entry)
    victim = ret;
}

struct list_elem *frame_victim(void) {
  if (list_empty(&frame_list)) {
      return NULL;
  }

  if (victim == NULL || victim == list_end(&frame_list)) {
      victim = list_begin(&frame_list);
  } 
  else {
    victim = list_next(victim);
    if (victim == list_end(&frame_list)) {
        victim = list_begin(&frame_list);
    }
  }

  return victim;
}

void frame_evict(void) {
  struct frame *frame = NULL;
  struct frame *entry;

  while (1) {
    entry = list_entry(frame_victim(), struct frame, elem);
    if (!pagedir_is_accessed(entry->owner->pagedir, entry->pte->vaddr)) {
      frame = entry;
      break;
    }
    pagedir_set_accessed(entry->owner->pagedir, entry->pte->vaddr, false);
  }

  bool is_dirty = pagedir_is_dirty(frame->owner->pagedir, frame->pte->vaddr);

  switch (frame->pte->type) {
    case MAPPED:
      if (is_dirty) {
          file_write_at(frame->pte->file, frame->kaddr, frame->pte->read_bytes, frame->pte->offset);
      }
      break;
    case BINARY:
      if (is_dirty || frame->pte->type == SWAPPED) {
          frame->pte->swap_slot = swap_out(frame->kaddr);
          frame->pte->type = SWAPPED;
      }
      break;
    case SWAPPED:
      frame->pte->swap_slot = swap_out(frame->kaddr);
      break;
    default:
        break;
  }

  frame->pte->loaded = false;

  frame_remove(frame);
  pagedir_clear_page(frame->owner->pagedir, frame->pte->vaddr);
  palloc_free_page(frame->kaddr);
  free(frame);
}
