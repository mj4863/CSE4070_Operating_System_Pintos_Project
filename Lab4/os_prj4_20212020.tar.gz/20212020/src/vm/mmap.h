#ifndef VM_MMAP_H
#define VM_MMAP_H

#include <list.h>
#include "filesys/file.h"

struct mmap_entry {
    unsigned int mapping_id;
    struct file *mapped_file;
    struct list page_table_entries;
    struct list_elem list_element;
};

unsigned int mm_map(int file_descriptor, void *address);
void mm_free(unsigned int mapping_id);

struct file *get_file_by_fd(int file_descriptor);
struct mmap_entry *get_mapping_by_id(unsigned int mapping_id);
bool create_page_entries(struct mmap_entry *entry, void *start_address);
void remove_mapping(struct mmap_entry *entry);

#endif /* VM_MMAP_H */
