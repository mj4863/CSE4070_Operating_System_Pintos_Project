#ifndef VM_PAGE_H
#define VM_PAGE_H

#include <hash.h>
#include "filesys/file.h"
#include "userprog/pagedir.h"
#include "threads/palloc.h"

typedef enum
{
  BINARY,
  MAPPED,
  SWAPPED
} pt_type;

struct pt_entry
{
  void *vaddr;
  pt_type type;
  
  size_t offset;
  size_t read_bytes;
  size_t zero_bytes;
  size_t swap_slot;

  struct file *file;
  struct hash_elem elem;
  struct list_elem mm_elem;

  bool writable;
  bool loaded;

};

void pt_init(struct hash *pt);
void pt_destroy(struct hash *pt);
struct pt_entry *pt_create(void *vaddr, pt_type type, bool writable, bool loaded, struct file *file, size_t offset, size_t read_bytes, size_t zero_bytes);
struct pt_entry *pt_find(void *vaddr);
bool pt_insert(struct hash *pt, struct pt_entry *pte);
bool pt_delete(struct hash *pt, struct pt_entry *pte);

#endif