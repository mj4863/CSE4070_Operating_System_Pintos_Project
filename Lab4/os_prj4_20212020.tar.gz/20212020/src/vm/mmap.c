#include "vm/swap.h"
#include "vm/mmap.h"
#include "vm/page.h"
#include "vm/frame.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/malloc.h"
#include "userprog/pagedir.h"
#include "userprog/syscall.h"
#include "filesys/off_t.h"

extern struct lock file_lock;

unsigned int mm_map(int file_descriptor, void *address) {
    if (address == NULL || pg_ofs(address) || is_kernel_vaddr(address) || pt_find(address)) {
        return (unsigned int)-1;
    }

    lock_acquire(&file_lock);
    struct file *file = file_reopen(get_file_by_fd(file_descriptor));
    lock_release(&file_lock);

    if (!file) {
        return (unsigned int)-1;
    }

    struct mmap_entry *new_entry = malloc(sizeof(struct mmap_entry));
    if (!new_entry) {
        file_close(file);
        return (unsigned int)-1;
    }

    new_entry->mapped_file = file;
    new_entry->mapping_id = thread_current()->map_list_size++;
    list_init(&new_entry->page_table_entries);
    list_push_back(&thread_current()->map_list, &new_entry->list_element);

    if (!create_page_entries(new_entry, address)) {
        remove_mapping(new_entry);
        return (unsigned int)-1;
    }

    return new_entry->mapping_id;
}

void mm_free(unsigned int mapping_id) {
    struct mmap_entry *entry = get_mapping_by_id(mapping_id);
    if (!entry) {
        return;
    }

    remove_mapping(entry);
    list_remove(&entry->list_element);
    free(entry);
}

struct file *get_file_by_fd(int file_descriptor) {
    if (file_descriptor < 3 || file_descriptor >= 128) return NULL;
    return thread_current()->fd[file_descriptor];
}

struct mmap_entry *get_mapping_by_id(unsigned int mapping_id) {
    struct list *mapping_list = &thread_current()->map_list;
    for (struct list_elem *elem = list_begin(mapping_list); elem != list_end(mapping_list); elem = list_next(elem)) {
        struct mmap_entry *entry = list_entry(elem, struct mmap_entry, list_element);
        if (entry->mapping_id == mapping_id) {
            return entry;
        }
    }
    return NULL;
}

bool create_page_entries(struct mmap_entry *entry, void *start_address) {
    off_t file_size = file_length(entry->mapped_file);
    off_t offset = 0;

    while (file_size > 0) {
        size_t bytes_to_read = file_size < PGSIZE ? file_size : PGSIZE;
        size_t bytes_to_zero = PGSIZE - bytes_to_read;

        struct pt_entry *pte = pt_create(start_address, MAPPED, true, false, entry->mapped_file, offset, bytes_to_read, bytes_to_zero);
        if (!pte)
            return false;

        pt_insert(&thread_current()->pt, pte);
        list_push_back(&entry->page_table_entries, &pte->mm_elem);

        start_address += PGSIZE;
        offset += PGSIZE;
        file_size -= bytes_to_read;
    }

    return true;
}

void remove_mapping(struct mmap_entry *entry) {
    struct list *pte_list = &entry->page_table_entries;
    struct thread *current_thread = thread_current();

    for (struct list_elem *elem = list_begin(pte_list); elem != list_end(pte_list); ) {
        struct pt_entry *pte = list_entry(elem, struct pt_entry, mm_elem);

        if (pte->loaded && pagedir_is_dirty(current_thread->pagedir, pte->vaddr)) {
            lock_acquire(&file_lock);
            if (file_write_at(pte->file, pte->vaddr, pte->read_bytes, pte->offset) != (off_t)pte->read_bytes) {
                NOT_REACHED();
            }
            lock_release(&file_lock);
            frame_free(pagedir_get_page(current_thread->pagedir, pte->vaddr));
        }

        elem = list_remove(elem);
        pt_delete(&current_thread->pt, pte);
    }
}
