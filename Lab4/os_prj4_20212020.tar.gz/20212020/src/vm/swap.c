#include "vm/swap.h"
#include "vm/mmap.h"
#include "vm/page.h"
#include "vm/frame.h"
#include "devices/block.h"
#include "threads/synch.h"
#include "threads/vaddr.h"

struct block *swap_block;
struct lock swap_lock;
struct bitmap *swap_bitmap;

void swap_init(void)
{
  lock_init(&swap_lock);
  swap_bitmap = bitmap_create(PGSIZE);
}

void swap_in(size_t index, void *kaddr)
{
  if (index == 0) {
    NOT_REACHED();
    return;
  }

  size_t swap_index = index - 1;

  lock_acquire(&swap_lock);
  bool success = swap_data(swap_index, kaddr, true);

  if (success) 
    bitmap_set(swap_bitmap, swap_index, false);

  lock_release(&swap_lock);
}

size_t swap_out(void *kaddr)
{
  swap_block = block_get_role(BLOCK_SWAP);

  lock_acquire(&swap_lock);
  size_t swap_index = find_swap_index();
  bool success = swap_data(swap_index, kaddr, false);

  if (success) {
    bitmap_set(swap_bitmap, swap_index, true);
  }

  lock_release(&swap_lock);
  
  return swap_index + 1;
}

bool swap_data(size_t swap_index, void *kaddr, bool is_read)
{
  for (int i = 0; i < 8; i++) {
    size_t sector = swap_index * 8 + i;
    void *sector_addr = kaddr + BLOCK_SECTOR_SIZE * i;
    if (is_read)
      block_read(swap_block, sector, sector_addr);
    else
      block_write(swap_block, sector, sector_addr);
  }
  return true;
}

size_t find_swap_index(void)
{
  size_t swap_index = bitmap_scan_and_flip(swap_bitmap, 0, 1, false);
  if (swap_index == BITMAP_ERROR)
    return BITMAP_ERROR;
  return swap_index;
}

void swap_free(size_t index)
{
  if (index == 0)
    return;

  lock_acquire(&swap_lock);
  bitmap_set_multiple(swap_bitmap, index - 1, 1, false);
  lock_release(&swap_lock);
}