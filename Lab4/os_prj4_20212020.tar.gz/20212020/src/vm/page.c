#include <string.h>
#include "threads/vaddr.h"
#include "threads/malloc.h"
#include "vm/page.h"
#include "vm/frame.h"
#include "vm/swap.h"

unsigned hash_func(const struct hash_elem *e, void *aux)
{
  struct pt_entry *pte = hash_entry(e, struct pt_entry, elem);

  return hash_int(pte->vaddr);
}

bool cmp_func(const struct hash_elem *a, const struct hash_elem *b) 
{
  struct pt_entry *a_Entry = hash_entry(a, struct pt_entry, elem);
	struct pt_entry *b_Entry = hash_entry(b, struct pt_entry, elem);

  return a_Entry->vaddr < b_Entry->vaddr;
}

void func_destroy(struct hash_elem *e, void *aux)
{
  struct pt_entry *pte = hash_entry(e, struct pt_entry, elem);
  if (pte) 
  {
    void *page = pagedir_get_page(thread_current()->pagedir, pte->vaddr);

    if (page) frame_free(page);

    free(pte);
  }
}

void pt_init(struct hash *pt)
{
  hash_init(pt, hash_func, cmp_func, NULL);
}

void pt_destroy(struct hash *pt)
{
  hash_destroy(pt, func_destroy);
}

struct pt_entry *pt_create(void *vaddr, pt_type type, bool writable, bool loaded, struct file *file, size_t offset, size_t read_bytes, size_t zero_bytes)
{
  struct pt_entry *pte = (struct pt_entry *)malloc(sizeof(struct pt_entry));
  memset(pte, 0, sizeof(struct pt_entry));

  pte->vaddr = vaddr;
  pte->type = type;
  pte->file = file;
  pte->offset = offset;
  
  pte->read_bytes = read_bytes;
  pte->zero_bytes = zero_bytes;
  pte->loaded = loaded;
  pte->writable = writable;

  return pte;
}

bool pt_insert(struct hash *pt, struct pt_entry *pte)
{
  struct hash_elem *elem = hash_insert(pt, &(pte->elem));

  if (elem == NULL) 
    return true;

  return false;
}

bool pt_delete(struct hash *pt, struct pt_entry *pte)
{
  struct hash_elem *elem = hash_delete(pt, &(pte->elem));

  if (elem == NULL)
    return false;

  frame_free(pagedir_get_page(thread_current()->pagedir, pte->vaddr));
  free(pte);
  return true;
}

struct pt_entry *pt_find(void *vaddr)
{
	struct pt_entry target;
	struct hash_elem *tmp;

	target.vaddr = pg_round_down(vaddr);
	tmp = hash_find(&(thread_current()->pt), &(target.elem));

	if (tmp)
		return hash_entry(tmp, struct pt_entry, elem);

  return NULL;
}